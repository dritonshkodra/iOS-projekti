

import UIKit

class Constants: NSObject {

   static var baseUrl = "http://pgbovine.net/photos/json-files/boston.json"
    static var imageUrl = "http://pgbovine.net/new-galleries/boston/images/"
}
